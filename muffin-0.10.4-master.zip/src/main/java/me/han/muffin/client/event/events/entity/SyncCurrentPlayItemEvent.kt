package me.han.muffin.client.event.events.entity

data class SyncCurrentPlayItemEvent(val slot: Int)