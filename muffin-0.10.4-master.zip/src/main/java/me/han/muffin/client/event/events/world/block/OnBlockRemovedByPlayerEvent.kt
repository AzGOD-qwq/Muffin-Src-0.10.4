package me.han.muffin.client.event.events.world.block

import me.han.muffin.client.event.EventCancellable

class OnBlockRemovedByPlayerEvent: EventCancellable()