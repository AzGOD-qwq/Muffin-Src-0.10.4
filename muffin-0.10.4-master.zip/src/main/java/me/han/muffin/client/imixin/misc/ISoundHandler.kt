package me.han.muffin.client.imixin.misc

import net.minecraft.client.audio.SoundManager

interface ISoundHandler {
    val soundManager: SoundManager
}