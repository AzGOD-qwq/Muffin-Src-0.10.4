package me.han.muffin.client.gui.hud.item.component.client

import me.han.muffin.client.gui.hud.item.HudItem

object KeyStrokeItem: HudItem("KeyStroke", HudCategory.Client, 2, 100) {

    override fun drawScreen(mouseX: Int, mouseY: Int, partialTicks: Float) {
        super.drawScreen(mouseX, mouseY, partialTicks)
    }

}