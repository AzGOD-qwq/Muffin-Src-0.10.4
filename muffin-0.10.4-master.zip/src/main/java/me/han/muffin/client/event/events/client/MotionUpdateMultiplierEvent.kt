package me.han.muffin.client.event.events.client

class MotionUpdateMultiplierEvent {
    var factor = 1
}