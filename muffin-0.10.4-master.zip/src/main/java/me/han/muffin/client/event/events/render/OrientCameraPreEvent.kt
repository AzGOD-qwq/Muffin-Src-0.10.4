package me.han.muffin.client.event.events.render

data class OrientCameraPreEvent(var shouldIgnoreTrace: Boolean, var range: Float)