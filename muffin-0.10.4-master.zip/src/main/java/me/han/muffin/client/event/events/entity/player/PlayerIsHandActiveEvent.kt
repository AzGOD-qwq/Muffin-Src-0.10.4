package me.han.muffin.client.event.events.entity.player

import me.han.muffin.client.event.EventCancellable

class PlayerIsHandActiveEvent: EventCancellable()