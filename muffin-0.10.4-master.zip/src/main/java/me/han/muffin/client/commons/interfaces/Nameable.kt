package me.han.muffin.client.commons.interfaces

interface Nameable {
    val name: String
}