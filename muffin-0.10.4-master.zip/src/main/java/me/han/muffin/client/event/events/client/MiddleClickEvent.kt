package me.han.muffin.client.event.events.client

class MiddleClickEvent