package me.han.muffin.client.event.events.world

import net.minecraft.client.multiplayer.WorldClient

class WorldClientInitEvent(val worldClient: WorldClient)