package me.han.muffin.client.imixin.world

interface IWorldProvider {
    var lightBrightnessTable: FloatArray
}