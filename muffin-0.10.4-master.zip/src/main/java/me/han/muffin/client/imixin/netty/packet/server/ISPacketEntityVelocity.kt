package me.han.muffin.client.imixin.netty.packet.server

interface ISPacketEntityVelocity {

    fun setMotionX(motionX: Int)
    fun setMotionY(motionY: Int)
    fun setMotionZ(motionZ: Int)

}