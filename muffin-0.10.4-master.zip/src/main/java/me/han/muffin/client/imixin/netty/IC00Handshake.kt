package me.han.muffin.client.imixin.netty

interface IC00Handshake {
    var ip: String
    var port: Int
}