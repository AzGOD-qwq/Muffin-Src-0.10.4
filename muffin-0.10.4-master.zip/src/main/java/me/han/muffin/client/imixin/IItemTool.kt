package me.han.muffin.client.imixin

interface IItemTool {
    val attackDamage: Float
}