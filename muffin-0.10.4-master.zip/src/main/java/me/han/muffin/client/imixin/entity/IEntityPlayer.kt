package me.han.muffin.client.imixin.entity

interface IEntityPlayer {
    var speedInAir: Float
}