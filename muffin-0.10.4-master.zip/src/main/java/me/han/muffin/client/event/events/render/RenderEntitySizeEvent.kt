package me.han.muffin.client.event.events.render

import me.han.muffin.client.event.EventStageable

data class RenderEntitySizeEvent(val stage: EventStageable.EventStage)