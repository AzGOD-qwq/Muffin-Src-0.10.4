package me.han.muffin.client.imixin.render

interface IFrustum {

    val x: Double
    val y: Double
    val z: Double

}