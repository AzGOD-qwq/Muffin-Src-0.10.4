package me.han.muffin.client.event.events.client

data class MouseEvent(val button: Int)