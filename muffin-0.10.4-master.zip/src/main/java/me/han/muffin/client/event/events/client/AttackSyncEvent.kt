package me.han.muffin.client.event.events.client

import net.minecraft.entity.Entity

data class AttackSyncEvent(val entity: Entity)