package me.han.muffin.client.event.events.movement

import me.han.muffin.client.event.EventCancellable

class LandOnSlimeEvent: EventCancellable()