package me.han.muffin.client.commons.interfaces

interface Alias : Nameable {
    val alias: Array<out String>
}