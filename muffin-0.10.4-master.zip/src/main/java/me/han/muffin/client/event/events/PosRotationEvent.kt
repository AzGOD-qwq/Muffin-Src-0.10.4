package me.han.muffin.client.event.events

class PosRotationEvent {}