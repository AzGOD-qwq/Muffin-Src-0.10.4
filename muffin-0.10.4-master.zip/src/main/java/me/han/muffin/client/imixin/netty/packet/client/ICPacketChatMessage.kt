package me.han.muffin.client.imixin.netty.packet.client

interface ICPacketChatMessage {
    fun setMessage(message: String)
}