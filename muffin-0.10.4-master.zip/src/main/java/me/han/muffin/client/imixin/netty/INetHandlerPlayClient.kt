package me.han.muffin.client.imixin.netty

interface INetHandlerPlayClient {
    val doneLoadingTerrain: Boolean
}