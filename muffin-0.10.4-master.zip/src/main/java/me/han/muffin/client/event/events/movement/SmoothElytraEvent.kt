package me.han.muffin.client.event.events.movement

data class SmoothElytraEvent(var isWorldRemote: Boolean)