package me.han.muffin.client.event.events.client

import me.han.muffin.client.event.EventStageable

class RenderTickEvent(val stage: EventStageable.EventStage)