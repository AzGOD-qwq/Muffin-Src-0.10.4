package me.han.muffin.client.imixin.netty.packet.server

interface ISPacketCloseWindow {
    var windowId: Int
}