package me.han.muffin.client.event.events.entity

import me.han.muffin.client.event.EventCancellable

class PigTravelEvent: EventCancellable()