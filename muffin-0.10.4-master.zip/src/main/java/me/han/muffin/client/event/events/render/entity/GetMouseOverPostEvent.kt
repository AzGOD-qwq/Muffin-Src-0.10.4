package me.han.muffin.client.event.events.render.entity

import net.minecraft.util.math.RayTraceResult

data class GetMouseOverPostEvent(var result: RayTraceResult?)