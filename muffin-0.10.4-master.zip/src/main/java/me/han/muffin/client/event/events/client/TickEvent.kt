package me.han.muffin.client.event.events.client

import me.han.muffin.client.event.EventStageable

data class TickEvent(val stage: EventStageable.EventStage)